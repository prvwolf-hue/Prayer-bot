require('./server');
require('./bot');
